import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:prjgetxproduct/cart/presentation/controllers/cart_controller.dart';

class CartPage extends GetView<CartController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Sản phẩm trong giỏ hàng",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
      ),
      body: Obx(() {
        if (controller.cartList.isEmpty) {
          return Center(
            child: Column(
              children: [
                Icon(Icons.hourglass_empty),
                const Text("Không có sản phẩm nào trong giỏ hàng"),
              ],
            ),
          );
        }
        return ListView.builder(
          itemCount: controller.cartList.length,
          itemBuilder: (context, index) {
            final product = controller.cartList.value[index];
            return Card(
              elevation: 4,
              shadowColor: Colors.grey.withOpacity(0.5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                side: BorderSide(color: Colors.green),
              ),
              child: ListTile(
                leading: CircleAvatar(
                  child: Image.network(
                    product.image,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Image.asset("assets/images/logo.png");
                    },
                  ),
                ),
                title: Text(
                  product.name,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  "${product.price}đ",
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                trailing: IconButton(
                  onPressed: () async {
                    controller.removeCart(product.id);
                  },
                  icon: Icon(Icons.delete),
                ),
              ),
            );
          },
        );
      }),
    );
  }
}
