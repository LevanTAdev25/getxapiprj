class NoParams {
  const NoParams();
}
